
public class Empleado {
	private String nombre;
	
	//CONSTRUCTORES
	Empleado(String nombre){
		this.nombre=nombre;
	}
	
	Empleado(){
		
	}
		
	//SETTERS Y GETTERS
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	//TOSTRING
	public String toString() {
		return "Empleado " +nombre;
	}		
}
