
public class Operario extends Empleado{

	Operario(String nombre){
		super(nombre);
	}
	
	Operario(){
		super();
	}
	
	//TOSTRING
	public String toString() {
		return super.toString() +" -> Operario";
	}	
}
