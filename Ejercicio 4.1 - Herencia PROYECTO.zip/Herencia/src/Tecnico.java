
public class Tecnico extends Operario{

	Tecnico(String nombre){
		super(nombre);
	}
	
	Tecnico(){
		super();
	}
	
	//TOSTRING
	public String toString() {
		return super.toString() +" -> Tecnico";
	}	
}
