
public class Directivo extends Empleado{

	Directivo(String nombre){
		super(nombre);
	}
	
	Directivo(){
		super();
	}
	
	//TOSTRING
	public String toString() {
		return super.toString() +" -> Directivo";
	}
}