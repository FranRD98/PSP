
public class Oficial extends Operario{

	Oficial(String nombre){
		super(nombre);
	}
	
	Oficial(){
		super();
	}
	
	//TOSTRING
	public String toString() {
		return super.toString() +" -> Oficial";
	}	
}
